#ifndef TEST_H
#define TEST_H

PyObject * pyAlgo(PyObject* self, PyObject* args);

#endif